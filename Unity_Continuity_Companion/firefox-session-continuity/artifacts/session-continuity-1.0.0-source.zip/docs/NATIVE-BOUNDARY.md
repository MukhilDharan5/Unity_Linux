# Exact native-companion boundary

`extension/src/storage/adapter.js` defines the logical asynchronous contract. `LocalRepository` in `storage/repository.js` is the functioning implementation. `NativeCompanionAdapter` is an unavailable stub with `available = false`; initialization rejects with an unavailable/TODO error. It is not instantiated by the extension. The UI always labels it **Native companion: unavailable**, never connected.

Required logical operations:

```text
initialize()                         -> Promise<void>
save(snapshot, {active?, epoch?})     -> Promise<committedSnapshot>
load(contextId)                      -> Promise<snapshot | null>
loadLatestActive()                   -> Promise<snapshot | null>
list()                              -> Promise<snapshot[]>
delete(contextId)                    -> Promise<void>
clear()                             -> Promise<void>
selectActive(contextId | null)       -> Promise<void>
close(contextId)                     -> Promise<void>
settings()                          -> Promise<settings>
changePolicy(settingsPatch, action?) -> Promise<committedSettings>
```

The local implementation also exposes `maintain()` for periodic retention. Any replacement must preserve active selection separately from write recency, revision ordering, failure acknowledgements, privacy barriers/epochs, corruption isolation, and all logical schema validation. Tracking/restoration consume logical objects and do not inspect the local storage key or envelope. Runtime routing remains browser-owned even if a future persistence adapter changes.

Tests use an independent `InMemoryAdapter` to exercise this substitution. It is only an in-memory test backend; it does not impersonate or simulate a native companion.

TODOs for a separate future project: requirements, threat model, user installation/consent, actual availability detection, transactional durability, serialization and migration, and a failure-aware adapter implementation. Language, transport, protocol, native-host identity, authentication, deployment, and CSV representation remain **undecided**.

This delivery intentionally contains no native messaging call, nativeMessaging permission, native host manifest, executable, installer, native protocol, companion-language choice, fake companion, or CSV writer. The CSV design concerns in [SCHEMA.md](SCHEMA.md) are requirements for future deliberation, not an implemented contract.
